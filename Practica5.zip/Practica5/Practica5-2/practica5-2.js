if (window.attachEvent) {
    window.attachEvent("onload", inicio);
} else if (window.addEventListener) {
    window.addEventListener("load", inicio);
}

function inicio() {
    let boton = document.getElementById("calcular");
    if (window.attachEvent) {
        boton.attachEvent("onclick", procesar);
    } else if (window.addEventListener) {
        boton.addEventListener("click", procesar);
    }
}

function procesar() {

    let conexion;

    if (window.XMLHttpRequest) {
        conexion = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        conexion = new ActiveXObject("Microsoft.XMLHTTP");
    }

    if (window.addEventListener) {
        conexion.addEventListener("readystatechange", recibido);
        //add more events if nedded
    } else if (window.attachEvent) {
        conexion.attachEvent("onreadystatechange", recibido);
    }

    let caras = document.getElementById("caras").value;
    let vertices = document.getElementById("vertices").value;

    let formData = new FormData();
    formData.append("caras", caras);
    formData.append("vertices", vertices);


    conexion.open("POST", "practica5-2.php", true);
   // conexion.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    conexion.send(formData);
}

function recibido(event) {
    let conexion = event.target;
    if (conexion.readyState === 4) {
        if (conexion.status === 200) {
            let respuesta = conexion.responseText;
            
            let aristas= document.getElementById("aristas");
            aristas.value = respuesta;
        }
    }
}