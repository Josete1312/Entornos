<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (isset($_POST['caras']) && isset($_POST['vertices'])) {
        $caras = $_POST['caras'];
        $vertices = $_POST['vertices'];
        $aristas = $caras + $vertices - 2;

        echo $aristas;
    }else{
        echo "Faltan parámetros";
    }
    
} else {
    echo "Método no permitido";
}
