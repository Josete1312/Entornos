
if (window.attachEvent) {
    window.attachEvent("onload", inicio);
} else if (window.addEventListener) {
    window.addEventListener("load", inicio);
}

function inicio() {
    let boton = document.getElementById("buscar");
    if (window.attachEvent) {
        boton.attachEvent("onclick", procesar);
    } else if (window.addEventListener) {
        boton.addEventListener("click", procesar);
    }
}

function procesar() {

    let conexion;

    if (window.XMLHttpRequest) {
        conexion = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        conexion = new ActiveXObject("Microsoft.XMLHTTP");
    }

    if (window.addEventListener) {
        conexion.addEventListener("readystatechange", recibido);
    } else if (window.attachEvent) {
        conexion.attachEvent("onreadystatechange", recibido);
    }

    let autor = document.getElementById("autores").value;
    conexion.open("GET", "practica5.php?autor=" + autor);
    conexion.send();




}

function recibido(evento) {
    let conexion = evento.target;
    if (conexion.readyState == 4) {
        if (conexion.status == 200) {
            let response = conexion.responseText;
            document.getElementById("libro").value = response;
        }
    }
    // console.log(response);

}