<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $input = fopen("php://input", "r"); //recoje el body de la petición
    $valor = fgets($input); //lee la linea del body que es un string con el xml
    $muestra = simplexml_load_string($valor); //convierte el string en un objeto simplexml

    $caras = $muestra->caras;
    $vertices = $muestra->vertices;



    $aristas = $caras + $vertices - 2;

    echo $aristas;
    
} else {
    echo "Método no permitido";
}
