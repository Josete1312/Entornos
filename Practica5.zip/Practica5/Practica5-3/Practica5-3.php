<?php

if($_SERVER['REQUEST_METHOD'] === 'POST') {

    $input=fopen("php://input", "r"); //recoje el body de la petición
    $valor=fgets($input); //lee la linea del body que es un string con el xml
    $xml = new SimpleXMLElement($valor); //convierte el string en un objeto xml

    $arrayRegiones=array();

    $seleccion=array();
   
    
    foreach($xml->region as $region) {
       switch ($region) {
        case 'alemania':
            array_push($seleccion, "Baden-Wurtemberg", "Baviera", "Berlín", "Brandeburgo", "Bremen", "Hamburgo", "Hesse", "Mecklemburgo-Pomerania  Occidental", "Baja  Sajonia", "Renania  del Norte-Westfalia", "Renania-Palatinado", "Sarre", "Sajonia", "Sajonia-Anhalt", "Shleswig-Holstein", "Turingia");
            break;
        case 'espana':
           
            array_push($seleccion, "Galicia", "Asturias", "Cantabria", "País Vasco", "Navarra", "Aragón", "Cataluña", "La Rioja", "Castilla León", "Comunidad Valenciana", "Madrid", "Extremadura", "Castilla La Mancha", "Murcia", "Andalucía", "Islas Canarias", "Islas Baleares", "Ceuta", "Melilla");
            break;
        case 'francia':
           
            array_push($seleccion, "Alsacia", "Aquitania", "Auvernia", "Borgona", "Bretaña", "Champagne-Ardenne", "Córcega", "Franche-Comté", "Languedoc-Roussillon", "Limousin", "Lorraine", "Midi-Pirineos", "Nord Pas-de-Calais", "Normandía", "País del Loira", "Paris Ile-de-France", "Picardía", "Poitou-Charentes", "Provenza", "Rhône-Alpes", "Riviera Costa Azul", "Valle del Loira");
            break;
        case 'inglaterra':
            array_push($seleccion, "Gran Londres (Greater London)", "Sudeste de Inglaterra (South East England)", "Sudoeste de Inglaterra (South West England)", "Midlands del Oeste (West Midlands)", "Noroeste de Inglaterra (North West England)", "Nordeste de Inglaterra (North East England)", "Yorkshire y Humber (Yorkshire and the Humber)", "Midlands Oriental (East Midlands)", "Este de Inglaterra (East of England)");
            break;
        case 'italia':
            array_push($seleccion, "Abruzzo", "Basilicata", "Calabria", "Campania", "Cerdeña", "Emilia Romagna", "Friuli-Venezia Giulia", "Lazio", "Liguria", "Lombardia", "Marche", "Molise", "Piamonte", "Puglia", "Sicilia", "Toscana", "Trentino Alto Adige", "Umbria", "Valle d'Aosta", "Veneto");
            break;
        case 'portugal':
            array_push($seleccion, "Alentejo", "Algarve", "Gran Lisboa", "Región de Lisboa", "Lisboa y Valle del Tajo", "Regiones Autónomas de Portugal", "Región Centro (Portugal)", "Región Norte (Portugal)");
            break;
        
        default:
            echo "No se ha seleccionado ninguna región";
            break;
       }
    }


    rsort($seleccion);
    header('Content-Type: text/xml');
    $xml="<regiones>";
    foreach($seleccion as $region) {
        $xml.="<region>".$region."</region>";
    }
    $xml.="</regiones>";

    echo $xml;


} else {
    echo "Método no permitido";
}

?>