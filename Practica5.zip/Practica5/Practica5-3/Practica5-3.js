  if (window.addEventListener) {
    window.addEventListener("load", inicio);
    
  }else if (window.attachEvent) {   
    window.attachEvent("onload", inicio);
  }


  function inicio() {
    let boton = document.getElementById("boton");
    if (window.addEventListener) {
        boton.addEventListener("click", procesar);
    } else if (window.attachEvent) {
        boton.attachEvent("onclick", procesar);
    }

}

function procesar() {

    let regiones=document.getElementById("regiones").selectedOptions;
    let xml="<paises>";
    for(let region of regiones){
       xml+="<region>"+region.value+"</region>";
    }  
    xml+="</paises>";

    let conexion;
    if (window.XMLHttpRequest) {
        conexion = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        conexion = new ActiveXObject("Microsoft.XMLHTTP");
    }

    if (window.addEventListener) {
        conexion.addEventListener("readystatechange", recibido);
    } else if (window.attachEvent) {
        conexion.attachEvent("onreadystatechange", recibido);
    }


    conexion.open("POST", "practica5-3.php");
    conexion.setRequestHeader("Content-Type", "text/xml");
    conexion.send(xml);
}


function recibido(event) {

    let conexion = event.target;
    if (conexion.readyState == 4 && conexion.status == 200) {
        let respuesta = conexion.responseXML;
        let paises = respuesta.getElementsByTagName("region");
        let regionesUl = document.getElementById("regionesUl");
        regionesUl.innerHTML = "";
        for (let pais of paises) {  

            let li = document.createElement("li");
            let text=document.createTextNode(pais.textContent);
            li.appendChild(text);
            regionesUl.appendChild(li);
        }

        
        console.log(paises);
    }
}