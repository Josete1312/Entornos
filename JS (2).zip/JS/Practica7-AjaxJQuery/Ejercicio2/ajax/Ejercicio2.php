<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['caras']) && isset($_POST['vertices'])) {
        $cara = intval($_POST['caras']);
        $verti = intval($_POST['vertices']);
        
        $aristas = $cara + $verti - 2;

        echo $aristas;
    } else {
        echo "Datos no válidos";
    }
} else {
    echo "Método de solicitud no soportado";
}
?>
