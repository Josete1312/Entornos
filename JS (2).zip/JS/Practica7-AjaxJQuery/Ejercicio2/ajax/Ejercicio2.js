$(window).on("load", inicio);

function inicio() {
    $("#calcular").on("click", procesar);
}

function procesar() {
    let car = $("#caras").val().trim();
    let ver = $("#vertices").val().trim();
    $.ajax({
        method: "POST",
        url: "Ejercicio2.php",
        data: { caras: car, vertices: ver },
        success: recibido
    });
}

function recibido(dato) {
    $("#aristas").val(dato);
}
