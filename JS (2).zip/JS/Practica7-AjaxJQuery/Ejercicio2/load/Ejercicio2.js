$(window).on("load", inicio);

function inicio() {
    $("#calcular").on("click", procesar);
}

function procesar() {
    let car = $('#caras').val();
    let ver = $('#vertices').val();
    $("#artist").load("Ejercicio2.php?" + $.param({ caras: car, vertices: ver }), function(dato) {
        $("#aristas").val(dato);
    });
}
