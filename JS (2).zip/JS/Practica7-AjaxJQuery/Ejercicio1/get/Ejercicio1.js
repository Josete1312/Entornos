$(window).on("load", inicio)

function inicio(){
	$("#obtener").on("click", procesar);
}

function procesar(){
    let aut = $('#autores').val();
    //$("#librito").load("Ejercicio1.php?"+$.param({autor:aut}), recibido);
    $.get("Ejercicio1.php",{autor:aut}, recibido);
}

function recibido(dato){
	$("#libroPrincipal").val(dato);	
}