 <?php
if (isset($_GET['autor'])) {
    $autor = $_GET['autor'];
    $librosPrincipales = array(
        "Gabriel García Márquez" => "Cien años de soledad",
        "J.K. Rowling" => "Harry Potter y la piedra filosofal",
        "J.R.R. Tolkien" => "El Señor de los Anillos",
        "George Orwell" => "1984",
        "Jane Austen" => "Orgullo y prejuicio",
        "Mark Twain" => "Las aventuras de Tom Sawyer",
        "Charles Dickens" => "Un cuento de Navidad",
        "Leo Tolstoy" => "Guerra y paz",
        "F. Scott Fitzgerald" => "El gran Gatsby",
        "Ernest Hemingway" => "El viejo y el mar",
        "William Shakespeare" => "Hamlet",
        "Agatha Christie" => "Asesinato en el Orient Express",
        "Virginia Woolf" => "La señora Dalloway",
        "Herman Melville" => "Moby Dick",
        "Haruki Murakami" => "Norwegian Wood"
    );

    $libroEncontrado = false;
    foreach ($librosPrincipales as $autorNombre => $libro) {
        if ($autorNombre === $autor) {
            echo $libro;
            $libroEncontrado = true;
            break;
        }
    }
}
?>