$(window).on("load", inicio)

function inicio(){
	$("#obtener").on("click", procesar);
}

function procesar(){
	let aut=$("#autores").val().trim();
	let objetoAjax={method:"GET",
					success:recibido,
	}
	$.ajax("Ejercicio1.php?autor="+aut,objetoAjax);
}

function recibido(dato){
	$("#libroPrincipal").val(dato);	
}