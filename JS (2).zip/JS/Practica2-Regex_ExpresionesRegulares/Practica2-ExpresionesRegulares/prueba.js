window.onload = inicio ;
function inicio(){ //lo de los colores siempre hay que ponerlo en la funcion inicio 
    document.formulario.onsubmit=validar;
    document.formulario.ciudad.onkeypress=sololetras;
    document.formulario.pais.onkeypress=sololetras;
    let elemento=document.formulario.elements;
    for (let i = 0; i < elemento.length; i++) {
      if(elemento[i].type=='text'){
          elemento[i].onfocus=entrar;
          elemento[i].onblur=salir;
      }
  }
}


function sololetras(evento) {
  let elevento=evento || window.event;
  let letra=String.fromCharCode(elevento.charCode).toLowerCase();
  let adicionales="áéíóúñ ";
  let admitido=true;
  if (letra<"a" || letra>"z") {
      if (!adicionales.includes(letra)) {
          admitido=false;
      }
  }
  return admitido;
}

function entrar(evento){
let elevento=evento || window.event;
      elevento.target.value=" ";
      elevento.target.style.color="green";
      elevento.target.style.backgroundColor="grey";
  }
  
  /*d.-) Cuando nos situemos sobre las cajas de texto su contenido se va a borrar, el
  color de los caracteres será amarillo y el color de fondo rojo, cuando
  abandonemos la caja de texto la visualización será la inicial */
  function salir(evento){
      let elevento=evento || window.event;
      elevento.target.style.color="black";
      elevento.target.style.backgroundColor="white";
  }

  


function validar() {
 
  let enviar = true;  /*hay que hacer un let por cada linea de <input type="text" name="codigo" en el html y se coge el name */
 
  let codigodetorneo = document.formulario.codigo.value;//de este let se saca hay que poner el mismo nombre
  let NombreTorneo = document.formulario.nombre.value;//
  let FechaTorneo = document.formulario.fecha.value;//
  let Golpes = document.formulario.golpes.value;
  let CiudadTorneo = document.formulario.ciudad.value;//
  let CodigoCiudad = document.formulario.codciudad.value;//
  let Pais = document.formulario.pais.value;//
  let MejorJugador = document.formulario.jugadormejor.value;
  let MejorGolpe = document.formulario.golpesmejor.value;
  let NombreUltimoGanador = document.formulario.ganador.value;
  let CuantiaPremio= document.formulario.ganancias.value;
  let CodigoEmpresa = document.formulario.empresa.value;
  let tipoTorneo =  document.formulario.tipo.value;
  let edadParticipantes = document.formulario.elements;
  let localidadesTorneo = document.formulario.paises;
  let mensaje = " ";
  let cuenta = 0;
  let contador = 0;





  if (!validarCodigoTorneo(codigodetorneo)) { //la variable codigodetorneo se saca de el let de arriba
      enviar = false;
      mensaje += 'Error en el campo Código del Torneo, dato no válido.\n';
  }

  if (!validarNombreTorneo(NombreTorneo)) {
      enviar = false;
      mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
  }

  if (!validarFechaTorneo(FechaTorneo)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarGolpes(Golpes)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarNombreTorneo(CiudadTorneo)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarCodigoCiudad(CodigoCiudad)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarPais(Pais)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarNombreMejor(MejorJugador)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarMejorGolpe(MejorGolpe)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarNombreUltimoGanador(NombreUltimoGanador)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarCuantiaPremio(CuantiaPremio)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}

if (!validarCodigoEmpresa(CodigoEmpresa)) {
    enviar = false;
    mensaje += 'Error en el campo Nombre del Torneo, dato no válido.\n';
}


    /*practica EE-02 alumnos.pdf
    ii. Se debe seleccionar un tipo de torneo. */
    if (tipoTorneo === "") {
      enviar = false;
      mensaje+="Error en tipo de torneo\n";
  }

/*12. ii.  //Se deben seleccionar al menos dos edades de participación en el torneo*/
for (let j=0; j<edadParticipantes.length; j++){
    if(edadParticipantes[j].type==="checkbox"){
        if(edadParticipantes[j].checked){
            cuenta+=1;
        }
    }
}

if (cuenta<2){
    enviar = false;
    mensaje+="Debes elegir como minimo dos edades\n";
}

for (let i=0; i<localidadesTorneo.length; i++){
    if (localidadesTorneo[i].selected){
        contador+=1;
    }
}

if (contador<5){
    enviar=false;
    mensaje+="Debes seleccionar al menos 5 localidades";
}

    if (!enviar) {
        alert(mensaje);
    }

    return enviar;

  }


/*practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
1. El código del torneo va a tener un conjunto letras que pueden tener
los valores “SER”, “ES”, “DEBE” y ”CAR”; a continuación tres dígitos,
luego dos caracteres que pueden ser cualquiera de los siguientes “#”,
“$”, “&”, “%”; le siguen cinco letras; continua con seis caracteres que
cada uno puede ser una letra, un dígito, los caracteres “/” y “+”;
sigue con seis letras y termina por tres dígitos o bien cuatro letras.  */
function validarCodigoTorneo(codigo) {
    let validarCodigoTorneo = /^(SER|ES|DEBE|CAR)[0-9]{3}[#$&%]{2}[A-Za-z]{5}[A-Za-z0-9/+]{6}[A-Za-z]{6}[0-9]{3}|[A-Za-z]{4}$/;
    return validarCodigoTorneo.test(codigo);
}

/* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
2.El nombre del torneo va a empezar por cinco letras, va a terminar
por dos caracteres que pueden ser letras, dígitos o el punto; y en
medio va a tener una serie de caracteres que pueden ser letras,
dígitos o los caracteres “-“, “|”, “?”, y “¿”. Va a tener en total de 9 a
20 caracteres.*/
function validarNombreTorneo(nombre){
    let validarNombreTorneo = /^[A-Za-z]{5}[A-Za-z0-9-|?¿.]{2,14}[A-Za-z0-9.]$/;
    return validarNombreTorneo.test(nombre);
}

/* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
3.La fecha de celebración del torneo va a ser una fecha correcta en la
cual el día y el mes van a tener dos dígitos, el año va a tener 4 dígitos,
el caracteres separados va a ser “-“; vamos a considerar que el mes
de febrero tiene 29 días y el año va a ser un número comprendido
entre 1890 y 2075.*/
function validarFechaTorneo(fecha) {
    let validarFechaTorneo = /^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[012])-(18[90-99]|19[0-9]{2}|20[0-7][0-9]|2075)$/;
    return validarFechaTorneo.test(fecha);
}

/* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
4.El número de golpes del tornero va a ser un número que va a tener
de 2 a 4 dígitos, siendo su valor mínimo 75.*/
function validarGolpes(golpes) {
    let validarGolpes = /^(75|[8-9][0-9]|[1-9][0-9]{2}|[1-9][0-9]{3})$/;
    return validarGolpes.test(golpes);
  }

  /* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
5. La ciudad donde se celebra el torneo va a empezar por cuatro letras,
va a terminar por tres letras y en medio va a contener letras,
espacios, o los caracteres */

function validarCiudadTorneo(ciudad) {
    let regex = /^[A-Z0-9]{4}-[A-Z0-9]{2}$/;
    return regex.test(ciudad);
  }

  /* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
6. El código de la ciudad donde se celebra el torneo va a empezar por
dos letras; le siguen tres dígitos; continúa con uno de los siguientes
valores “ARPA”, “DOM”, “DE” o “POR”; continua por cinco letras y
termina por cuatro caracteres que pueden ser letras o dígitos. */
function validarCodigoCiudad(codigo) {
    let regex = /^[A-Za-z]{2}[0-9]{3}(ARPA|DOM|DE|POR)[A-Za-z]{5}[A-Za-z0-9]{4}$/;
    return regex.test(codigo);
  }

    /* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
7.El País donde se celebra el torneo va a tener uno de los siguientes
valores “USA”, “Inglaterra”, “Escocia”, “España” o “Japón”.*/
  function validarPais(pais) {
    let regex = /^[A-Za-z]{2}[0-9]{3}(ARPA|DOM|DE|POR)[A-Za-z]{5}[A-Za-z0-9]{4}$/;
    return regex.test(pais);
  }

/* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
8.La cuantía del premio va a ser un número real, que puede tener
parte decimal o no, en la parte entera puede tener hasta 7 dígitos
con un valor mínimo de 375000 y en la parte decimal puede tener
hasta dos decimales.*/
function validarCuantiaPremio(cuantia) {
    let regex = /^(375000|[1-9][0-9]{6}\.[0-9]{1,2}|[1-9][0-9]{0,6}\.[0-9]{1,2})$/;
    return regex.test(cuantia);
  }


  /* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
9.El nombre del jugador con el mejor recorrido del torneo va a
empezar por letra, va a terminar por letra y en medio va a tener
letras o espacios. Va a tener una longitud total de entre 12 y 20
caracteres.*/
  function validarNombreMejor(nombre) {
    let regex = /^[A-Za-z][A-Za-z\s]{10,18}[A-Za-z]$/;
    return regex.test(nombre);
  }

/*practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
10.. El número de golpes del mejor recorrido del torneo va a ser un
número que puede tener de 2 a 5 dígitos con un valor mínimo de
215.*/
  function validarMejorGolpe(golpes) {
    let regex = /^(2[0-9]{1,4}|[3-9][0-9]{1,3}|[1-9][0-9]{2})$/;
    return regex.test(golpes);
}

/* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
11.El nombre último ganador del torneo va a empezar por tres letras;
termina por cinco letras y en medio va a tener de 11 a 17 caracteres
que pueden ser letras, espacios o los caracteres “-“ y “º”*/
function validarNombreUltimoGanador(nombre) {
    let regex = /^[A-Za-z]{3}[A-Za-z\sº-]{11,17}[A-Za-z]{5}$/;
    return regex.test(nombre);
}
/* practica EE-02 alumnos.pdf
d.-) Para las validaciones deberemos tener en cuenta los siguientes puntos:
12. El código de la empresa que organiza el torneo va a tener 5 o 9
letras; a continuación va a tener 3 o 7 dígitos*/
function validarCodigoEmpresa(codigo) {
    let regex = /^[A-Za-z]{5}[0-9]{3}|[A-Za-z]{9}[0-9]{7}$/;
    return regex.test(codigo);
}
