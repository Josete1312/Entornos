$(document).ready(function() {
    // Apartado b
    $("#alcazar").mouseenter(function() {
        $(this).addClass("primero");
    });

    $("#alcazar").mouseleave(function() {
        $(this).removeClass("primero");
    });

    // Apartado c
    $("#medina").hover(function() {
        $(this).toggleClass("primero");
    });
});
