$(document).ready(function() {
    let imagenes = ["imagen1.png", "imagen2.png", "imagen3.png", "imagen4.png", "imagen5.png", "imagen6.png", "imagen7.png"];
    let indiceImagen = 0;
  
    $("#cambio-imagen").click(function() {
      indiceImagen = (indiceImagen + 1) % imagenes.length;
      $("#imagen").attr("src", imagenes[indiceImagen]);
    });
  
    $(".comunidad").click(function() {
      let comunidad = $(this).data("info");
      let infoContainer = $("#comunidades-info");
      infoContainer.empty();
  
      switch(comunidad) {
        case "Galicia":
          infoContainer.append('<div id="galicia-info" class="info"><h3>Información de Galicia</h3><ul><li>Provincia 1</li><li>Provincia 2</li><li>Provincia 3</li></ul></div>');
          break;
        case "Andalucia":
          infoContainer.append('<div id="andalucia-info" class="info"><h3>Información de Andalucía</h3><p>Andalucía es una comunidad autónoma española situada en el sur de la península ibérica, en la frontera con el norte de África. La capital es Sevilla.</p></div>');
          break;
        case "Cantabria":
          infoContainer.append('<div id="cantabria-info" class="info"><h3>Información de Cantabria</h3><p>Cantabria es una comunidad autónoma española situada al norte de la península ibérica. La capital es Santander.</p></div>');
          break;
        case "Castilla-León":
          infoContainer.append('<div id="castilla-leon-info" class="info"><h3>Información de Castilla y León</h3><p>Castilla y León es una comunidad autónoma española formada por las provincias históricas de Castilla la Vieja, León y parte de la Vieja Castilla. La capital es Valladolid.</p></div>');
          break;
        case "Asturias":
          infoContainer.append('<div id="asturias-info" class="info"><h3>Información de Asturias</h3><p>Asturias es una comunidad autónoma española situada en el norte de la península ibérica. La capital es Oviedo.</p></div>');
          break;
        default:
          break;
      }
    });
  });
  