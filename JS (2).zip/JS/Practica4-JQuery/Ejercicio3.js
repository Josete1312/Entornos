$(document).ready(function() {
    $("#añadir").click(function() {
      var codigo = $("#codigo").val().trim();
      var nombre = $("#nombre").val().trim();
      var error = $("#error-message");

      if (codigo === "" || isNaN(codigo) || nombre === "") {
        error.text("Error: Código debe ser un número y nombre no puede estar vacío.");
        return;
      }

      var tabla = $("#tabla tbody");
      var filaNueva = "<tr><td>" + codigo + "</td><td>" + nombre + "</td></tr>";
      var filas = tabla.find("tr");
      var encontrado = false;
      filas.each(function() {
        var fila = $(this);
        var codigoFila = parseInt(fila.find("td:eq(0)").text());
        if (codigoFila < parseInt(codigo)) {
          fila.before(filaNueva);
          encontrado = true;
          return false;
        }
      });

      if (!encontrado) {
        tabla.append(filaNueva);
      }

      error.text("");
    });

    $("#borrar").click(function() {
      var codigoBorrar = $("#codigoBorrar").val().trim();
      var error = $("#error-message");
      var encontrado = false;

      if (codigoBorrar === "") {
        error.text("Error: Introduce un código para borrar.");
        return;
      }

      $("#tabla tbody tr").each(function() {
        var fila = $(this);
        if (fila.find("td:eq(0)").text() === codigoBorrar) {
          fila.remove();
          encontrado = true;
          error.text("");
          return false;
        }
      });

      if (!encontrado) {
        error.text("Error: No se encontró el código en la tabla.");
      }
    });

    $("#modificar").click(function() {
      var codigoModificar = $("#codigoModificar").val().trim();
      var nuevoNombre = $("#nuevoNombre").val().trim();
      var error = $("#error-message");
      var encontrado = false;

      if (codigoModificar === "" || nuevoNombre === "") {
        error.text("Error: Introduce un código y un nuevo nombre.");
        return;
      }

      $("#tabla tbody tr").each(function() {
        var fila = $(this);
        if (fila.find("td:eq(0)").text() === codigoModificar) {
          fila.find("td:eq(1)").text(nuevoNombre);
          encontrado = true;
          error.text("");
          return false;
        }
      });

      if (!encontrado) {
        error.text("Error: No se encontró el código en la tabla.");
      }
    });

    $("#borrarFila").click(function() {
      var numeroFila = parseInt($("#numeroFila").val().trim());
      var error = $("#error-message");
      var tabla = $("#tabla tbody");

      if (isNaN(numeroFila) || numeroFila < 1 || numeroFila > tabla.find("tr").length) {
        error.text("Error: Número de fila inválido.");
        return;
      }

      tabla.find("tr:eq(" + (numeroFila - 1) + ")").remove();
      error.text("");
    });

    $("#borrarTodo").click(function() {
      $("#tabla tbody").empty();
      $("#error-message").text("");
    });
});

