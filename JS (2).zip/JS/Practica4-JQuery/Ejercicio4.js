$(document).ready(function() {
    $("#aplicacoches").click(function() {
      var colorFondoImpar = "rgb(" + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + ")";
      var colorFondoPar = "rgb(" + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + ")";

      $("#tablacoches tbody tr:odd").css("background-color", colorFondoImpar);
      $("#tablacoches tbody tr:even").css("background-color", colorFondoPar);
    });

    $("#aplicatabla").click(function() {
      var colorFondoImpar = "rgb(" + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + ")";
      var colorFondoPar = "rgb(" + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + "," + Math.floor(Math.random() * 256) + ")";

      $("#cochestabla tbody td:nth-child(odd)").css("background-color", colorFondoImpar);
      $("#cochestabla tbody td:nth-child(even)").css("background-color", colorFondoPar);
    });
  });