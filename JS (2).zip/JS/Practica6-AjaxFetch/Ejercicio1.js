if (document.addEventListener) {
    window.addEventListener("load", inicio);
} else if (document.attachEvent) {
    window.attachEvent("onload", inicio);
}

function inicio() {
    let botonObtener = document.getElementById("obtener");
    if (document.addEventListener) {
        botonObtener.addEventListener("click", obtenerLibro);
    } else if (document.attachEvent) {
        botonObtener.attachEvent("onclick", obtenerLibro);
    }
}

function obtenerLibro() {
    let autorSeleccionado = document.getElementById("autores").value;
    let url = `Ejercicio1.php?autor=${autorSeleccionado}`;

    let objetoFetch = {
        method: "GET",
        headers: { "Content-Type": "application/x-www-form-urlencoded" }
    };

    fetch(url, objetoFetch)
        .then(correcto)
        .catch(errores);
}

function correcto(respuesta) {
    if (respuesta.ok) {
        respuesta.text().then(recibido);
    } else {
        errores();
    }
}

function errores() {
    alert("Error en la conexión");
}

function recibido(dato) {
    document.getElementById("libroPrincipal").value = dato;
}
