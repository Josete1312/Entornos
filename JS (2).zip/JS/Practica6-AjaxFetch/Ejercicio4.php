<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $entrada = fopen('php://input', 'r');
    $datos = fgets($entrada);
    $valores = simplexml_load_string($datos);

    $paises = [
        "Alemania" => ["Baden-Wurtemberg", "Baviera", "Berlín", "Brandeburgo", "Bremen", 
                       "Hamburgo", "Hesse", "Mecklemburgo-Pomerania Occidental", 
                       "Baja Sajonia", "Renania del Norte-Westfalia", "Renania-Palatinado", 
                       "Sarre", "Sajonia", "Sajonia-Anhalt", "Shleswig-Holstein", "Turingia"],
        "España" => ["Galicia", "Asturias", "Cantabria", "País Vasco", "Navarra", "Aragón", 
                     "Cataluña", "La Rioja", "Castilla León", "Comunidad Valenciana", 
                     "Madrid", "Extremadura", "Castilla La Mancha", "Murcia", "Andalucía", 
                     "Islas Canarias", "Islas Baleares", "Ceuta", "Melilla"],
        "Francia" => ["Alsacia", "Aquitania", "Auvernia", "Borgona", "Bretaña", "Champagne-Ardenne", 
                      "Córcega", "Franche-Comté", "Languedoc-Roussillon", "Limousin", "Lorraine", 
                      "Midi-Pirineos", "Nord Pas-de-Calais", "Normandía", "País del Loira", 
                      "Paris Ile-de-France", "Picardía", "Poitou-Charentes", "Provenza", 
                      "Rhône-Alpes", "Riviera Costa Azul", "Valle del Loira"],
        "Inglaterra" => ["Gran Londres (Greater London)", "Sudeste de Inglaterra (South East England)", 
                         "Sudoeste de Inglaterra (South West England)", "Midlands del Oeste (West Midlands)", 
                         "Noroeste de Inglaterra (North West England)", "Nordeste de Inglaterra (North East England)", 
                         "Yorkshire y Humber (Yorkshire and the Humber)", "Midlands Oriental (East Midlands)", 
                         "Este de Inglaterra (East of England)"],
        "Italia" => ["Abruzzo", "Basilicata", "Calabria", "Campania", "Cerdeña", "Emilia Romagna", 
                     "Friuli-Venezia Giulia", "Lazio", "Liguria", "Lombardia", "Marche", "Molise", 
                     "Piamonte", "Puglia", "Sicilia", "Toscana", "Trentino Alto Adige", "Umbria", 
                     "Valle d'Aosta", "Veneto"],
        "Portugal" => ["Alentejo", "Algarve", "Gran Lisboa", "Región de Lisboa", "Lisboa y Valle del Tajo", 
                       "Regiones Autónomas de Portugal", "Región Centro (Portugal)", "Región Norte (Portugal)"]
    ];

    $nom = $valores->pais[0]->nombre;
    $regiones = obtenerRegiones($nom);

    $respuesta = "<regiones>";
    foreach ($regiones as $region) {
        $respuesta .= "<region>" . htmlspecialchars($region) . "</region>";
    }
    $respuesta .= "</regiones>";

    header("Content-type: text/xml");
    echo $respuesta;
} else {
    echo "Método de solicitud no soportado";
}

function obtenerRegiones($pais) {
    global $paises;
    return $paises[$pais];
}
?>
