if (document.addEventListener) {
    window.addEventListener("load", inicio);
} else if (document.attachEvent) {
    window.attachEvent("onload", inicio);
}

function inicio() {
    var boton = document.getElementById("obtener");
    if (document.addEventListener) {
        boton.addEventListener("click", procesar);
    } else if (document.attachEvent) {
        boton.attachEvent("onclick", procesar);
    }
}

function procesar() {
    var paises = document.getElementById("paises");
    var seleccionados = [];
    for (var i = 0; i < paises.options.length; i++) {
        if (paises.options[i].selected) {
            seleccionados.push(paises.options[i].value);
        }
    }

    if (seleccionados.length === 0) {
        alert("Por favor, seleccione al menos un país.");
        return;
    }

    var cadenaXML = "<paises>";
    seleccionados.forEach(function(pais) {
        cadenaXML += "<pais>" + pais + "</pais>";
    });
    cadenaXML += "</paises>";

    var objetoFetch = {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "xml=" + cadenaXML
    };

    fetch("Ejercicio4.php", objetoFetch)
        .then(function(respuesta) {
            if (respuesta.ok) {
                respuesta.text().then(function(dato) {
                    var parser = new DOMParser();
                    var xml = parser.parseFromString(dato, "application/xml");
                    var regiones = xml.getElementsByTagName("region");

                    var regionesArray = [];
                    for (var i = 0; i < regiones.length; i++) {
                        regionesArray.push(regiones[i].textContent);
                    }

                    regionesArray.sort();
                    regionesArray.reverse();

                    var selectRegiones = document.getElementById("regiones");
                    selectRegiones.innerHTML = "";
                    regionesArray.forEach(function(region) {
                        var option = document.createElement("option");
                        option.textContent = region;
                        selectRegiones.appendChild(option);
                    });
                });
            } else {
                errores();
            }
        })
        .catch(errores);
}

function errores() {
    alert("Error en la conexión");
}
