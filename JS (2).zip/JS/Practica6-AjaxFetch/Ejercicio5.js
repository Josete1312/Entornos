if (document.addEventListener) {
    window.addEventListener("load", inicio);
} else if (document.attachEvent) {
    window.attachEvent("onload", inicio);
}

function inicio() {
    var boton = document.getElementById("solucion");
    if (document.addEventListener) {
        boton.addEventListener("click", procesar);
    } else if (document.attachEvent) {
        boton.attachEvent("onclick", procesar);
    }
}

function procesar() {
    let a = parseFloat(document.getElementById("num1").value);
    let b = parseFloat(document.getElementById("num2").value);
    let c = parseFloat(document.getElementById("num3").value);

    if (isNaN(a) || isNaN(b) || isNaN(c)) {
        alert("Por favor, introduzca valores numéricos en todas las cajas de texto.");
        return;
    }

    let datos = {
        a: a,
        b: b,
        c: c
    };

    let objetoFetch = {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(datos)
    };

    fetch("Ejercicio5.php", objetoFetch)
        .then(function(respuesta) {
            if (respuesta.ok) {
                respuesta.json().then(function(resultado) {
                    document.getElementById("sol1").value = resultado.solucion1;
                    document.getElementById("sol2").value = resultado.solucion2;
                });
            } else {
                errores();
            }
        })
        .catch(errores);
}

function errores() {
    alert("Error en la conexión");
}
