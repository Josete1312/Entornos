if (document.addEventListener) {
    window.addEventListener("load", inicio);
} else if (document.attachEvent) {
    window.attachEvent("onload", inicio);
}

function inicio() {
    let botonCalcular = document.getElementById("calcular");
    if (document.addEventListener) {
        botonCalcular.addEventListener("click", realizarCalculo);
    } else if (document.attachEvent) {
        botonCalcular.attachEvent("onclick", realizarCalculo);
    }
}

function realizarCalculo() {
    let caras = document.getElementById("caras").value;
    let vertices = document.getElementById("vertices").value;

    if (caras === "" || vertices === "" || isNaN(caras) || isNaN(vertices)) {
        alert("Por favor, ingrese valores numéricos en las cajas de texto.");
        return;
    }

    let datos = `caras=${caras}&vertices=${vertices}`;

    let objetoFetch = {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: datos
    };

    fetch("Ejercicio2.php", objetoFetch)
        .then(correcto)
        .catch(errores);
}

function correcto(respuesta) {
    if (respuesta.ok) {
        respuesta.text().then(recibido);
    } else {
        errores();
    }
}

function errores() {
    alert("Error en la conexión");
}

function recibido(dato) {
    document.getElementById("aristas").value = dato;
}
