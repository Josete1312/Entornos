if (document.addEventListener) {
    window.addEventListener("load", inicio);
} else if (document.attachEvent) {
    window.attachEvent("onload", inicio);
}

function inicio() {
    let boton = document.getElementById("solucion");
    if (document.addEventListener) {
        boton.addEventListener("click", procesar);
    } else if (document.attachEvent) {
        boton.attachEvent("onclick", procesar);
    }
}

function procesar() {
    let conexion;
    if (window.XMLHttpRequest) {
        conexion = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        conexion = new ActiveXObject("Microsoft.XMLHTTP");
    }

    if (document.addEventListener) {
        conexion.addEventListener("readystatechange", recibido);
    } else if (document.attachEvent) {
        conexion.attachEvent("onreadystatechange", recibido);
    }

    // Obtener los coeficientes de la ecuación
    let a = parseFloat(document.getElementById("num1").value);
    let b = parseFloat(document.getElementById("num2").value);
    let c = parseFloat(document.getElementById("num3").value);

    // Verificar si los coeficientes son válidos
    if (isNaN(a) || isNaN(b) || isNaN(c)) {
        alert("Por favor, ingrese valores numéricos válidos para los coeficientes.");
        return;
    }

    // Crear objeto con los datos de la ecuación
    let data = {
        a: a,
        b: b,
        c: c
    };

    // Convertir objeto a JSON
    let jsonData = JSON.stringify(data);

    // Enviar la solicitud al servidor
    conexion.open("POST", "Ejercicio5.php", true);
    conexion.setRequestHeader("Content-Type", "application/json");
    conexion.send(jsonData);
}

function recibido(evento) {
    let conexion = evento.target;
    if (conexion.readyState == 4 && conexion.status == 200) {
        let respuesta = JSON.parse(conexion.responseText);
        document.getElementById("sol1").value = respuesta.solucion1;
        document.getElementById("sol2").value = respuesta.solucion2;
    }
}
