<?php
// Recibir los datos en formato JSON
$data = json_decode(file_get_contents('php://input'), true);

// Extraer los coeficientes de la ecuación
$a = $data['a'];
$b = $data['b'];
$c = $data['c'];

// Calcular el discriminante
$discriminante = $b * $b - 4 * $a * $c;

// Calcular las soluciones
if ($discriminante > 0) {
    $solucion1 = (-$b + sqrt($discriminante)) / (2 * $a);
    $solucion2 = (-$b - sqrt($discriminante)) / (2 * $a);
} elseif ($discriminante == 0) {
    $solucion1 = $solucion2 = -$b / (2 * $a);
} else {
    $solucion1 = $solucion2 = "No hay soluciones reales";
}

// Crear un array con las soluciones
$resultado = array(
    'solucion1' => $solucion1,
    'solucion2' => $solucion2
);

// Devolver las soluciones en formato JSON
echo json_encode($resultado);
?>
