if (document.addEventListener) {
    window.addEventListener("load", inicio);
} else if (document.attachEvent) {
    window.attachEvent("onload", inicio);
}

function inicio() {
    let boton = document.getElementById("calcular");
    if (document.addEventListener) {
        boton.addEventListener("click", procesar);
    } else if (document.attachEvent) {
        boton.attachEvent("onclick", procesar);
    }
}

function procesar() {
    let conexion;
    if (window.XMLHttpRequest) {
        conexion = new XMLHttpRequest();
    } else if (window.ActiveXObject) {
        conexion = new ActiveXObject("Microsoft.XMLHTTP");
    }

    if (document.addEventListener) {
        conexion.addEventListener("readystatechange", recibido);
    } else if (document.attachEvent) {
        conexion.attachEvent("onreadystatechange", recibido);
    }

    let caras = document.getElementById("caras").value;
    let vertices = document.getElementById("vertices").value;

    let datos = newFormData();
    datos.append("caras", caras);
    datos.append("vertices", vertices);

    if (isNaN(caras) || isNaN(vertices) || caras === '' || vertices === '') {
        alert("Por favor, ingrese valores numéricos válidos para caras y vértices.");
        return;
    }

    let parametros = "caras=" + caras + "&vertices=" + vertices;
    conexion.open("POST", "Ejercicio3.php", true);
    conexion.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    conexion.send(parametros);
    
    function recibido(evento) {
        let conexion = evento.target;
        if (conexion.readyState == 4) {
            if (conexion.status == 200) {
                document.getElementById("aristas").value = conexion.responseText;
            }
        }
    }
}