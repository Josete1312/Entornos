<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    por favor, introduzca su nombre y apellido para el registro.;
    <a href='./comregcli.php'>Volver</a>;

</body>

</html>