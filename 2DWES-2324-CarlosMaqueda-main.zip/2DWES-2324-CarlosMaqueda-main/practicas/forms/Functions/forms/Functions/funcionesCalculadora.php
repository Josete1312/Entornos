<?php

function suma($valor1, $valor2){
    
    $resultado=$valor1 + $valor2;

    return $resultado;
 
}
function resta($valor1, $valor2){
    
    $resultado=$valor1 - $valor2;

    return $resultado;
 
}

function multip($valor1, $valor2){
    
    $resultado=$valor1 * $valor2;

    return $resultado;
 
}

function division($valor1, $valor2){
    
    $resultado=$valor1 / $valor2;

    return $resultado;
 
}

?>