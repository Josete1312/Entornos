<?php
    session_start();
    //llamada a la vista

    require_once("../views/movdevolver.php");

?> 